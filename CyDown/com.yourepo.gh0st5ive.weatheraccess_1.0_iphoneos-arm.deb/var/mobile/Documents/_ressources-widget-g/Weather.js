var API_KEYS = ""; // past your key between the two quote 
var DEFAULT_WEATHER_ID = -1; // set your default weather location