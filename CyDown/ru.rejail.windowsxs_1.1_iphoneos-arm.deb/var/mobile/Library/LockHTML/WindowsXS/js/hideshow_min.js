function HideMusic() {
	document.getElementById("music_container").style.display = "none";
}

function HideWeather() {
	document.getElementById("weather_container").style.display = "none";
}

function ShowMusic() {
	document.getElementById("music_container").style.display = "unset";
}

function ShowWeather() {
	document.getElementById("weather_container").style.display = "unset";
}

function SetZIndexW() {
	document.getElementById("weather_container").style.zIndex = "2";
	document.getElementById("music_container").style.zIndex = "1";
}

function SetZIndexM() {
	document.getElementById("weather_container").style.zIndex = "1";
	document.getElementById("music_container").style.zIndex = "2";
}
