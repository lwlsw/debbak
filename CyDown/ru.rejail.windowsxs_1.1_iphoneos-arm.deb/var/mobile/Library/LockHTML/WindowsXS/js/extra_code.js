if (App1Name != "") {
	var innerDiv = document.createElement('div');
	innerDiv.setAttribute("id", "icon_1_click");
	innerDiv.className = 'icon_1_click';
	document.getElementById("desktop_items").appendChild(innerDiv);
	document.getElementById("icon_1_click").innerHTML = "<img class='desktop_icons' src='" + App1Icon + "'><div class='desktop_text'>" + App1Name + "</div>";
	document.getElementById("icon_1_click").addEventListener('click', 
		function(){ 
window.location = 'xeninfo:openapp:' + App1BundleID;
console.log("Opening " + App1BundleID);
		}
	, false);
}

if (App2Name != "") {
	var innerDiv = document.createElement('div');
	innerDiv.setAttribute("id", "icon_2_click");
	innerDiv.className = 'icon_2_click';
	document.getElementById("desktop_items").appendChild(innerDiv);
	document.getElementById("icon_2_click").innerHTML = "<img class='desktop_icons' src='" + App2Icon + "'><div class='desktop_text'>" + App2Name + "</div>";
	document.getElementById("icon_2_click").addEventListener('click', 
		function(){ 
window.location = 'xeninfo:openapp:' + App2BundleID;
console.log("Opening " + App2BundleID);
		}
	, false);
}


//DOESNT WORK
var i;
var icon = [App1Icon, App2Icon, App3Icon];
var label = [App1Name, App2Name, App3Name];
var bundleID = [App1BundleID, App2BundleID, App3BundleID];
for (i = 0; i < TotalApps; i++) { 
	var myClick = "icon_"+(i+1)+"_click";
	console.log("TotalApps");
	var innerDiv = document.createElement('div');
	innerDiv.setAttribute("id", myClick);
	innerDiv.className = myClick;
	document.getElementById("desktop_items").appendChild(innerDiv);
	document.getElementById(myClick).innerHTML = "<img class='desktop_icons' src='" + icon[i] + "'><div class='desktop_text'>" + label[i] + "</div>";
	document.getElementById(myClick).addEventListener('click', 
		function(){ 
			window.location = "xeninfo:openapp:" + bundleID[i];
			console.log("Opening " + bundleID[i]);
		}
	, false);
	console.log("Added BiD: " + bundleID[i]);
}
		
//